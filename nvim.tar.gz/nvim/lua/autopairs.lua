-- lua/autopairs.lua
local M = {}

local pares = {
  ["("] = ")",
  ["["] = "]",
  ["{"] = "}",
  ['"'] = '"',
  ["'"] = "'",
}

local fechamentos = { [")"] = true, ["]"] = true, ["}"] = true }

-- Caractere antes e depois do cursor (modo insert)
local function contexto()
  local linha = vim.api.nvim_get_current_line()
  local col = vim.api.nvim_win_get_cursor(0)[2] -- índice 0-based em bytes
  local antes = col > 0 and linha:sub(col, col) or ""
  local depois = linha:sub(col + 1, col + 1)
  return antes, depois
end

local function abrir(abre, fecha)
  return function()
    return abre .. fecha .. "<Left>"
  end
end

local function fechar(fecha)
  return function()
    local _, depois = contexto()
    if depois == fecha then
      return "<Right>" -- apenas pula o fechamento existente
    end
    return fecha
  end
end

local function aspas(q)
  return function()
    local antes, depois = contexto()
    -- Se o próximo char já é a aspa, pula por cima
    if depois == q then
      return "<Right>"
    end
    -- Não fecha par se vier depois de letra/número (ex.: don't) ou de outra aspa igual
    if antes:match("[%w_]") or antes == q then
      return q
    end
    return q .. q .. "<Left>"
  end
end

local function backspace()
  local antes, depois = contexto()
  if pares[antes] and pares[antes] == depois then
    return "<BS><Del>" -- apaga o par inteiro
  end
  return "<BS>"
end

local function enter()
  local antes, depois = contexto()
  if (antes == "{" and depois == "}")
    or (antes == "(" and depois == ")")
    or (antes == "[" and depois == "]") then
    return "<CR><Esc>O" -- abre bloco indentado entre o par
  end
  return "<CR>"
end

function M.setup()
  local opts = { expr = true, noremap = true, silent = true }

  for abre, fecha in pairs(pares) do
    if abre == fecha then
      vim.keymap.set("i", abre, aspas(abre), opts)
    else
      vim.keymap.set("i", abre, abrir(abre, fecha), opts)
    end
  end

  for fecha in pairs(fechamentos) do
    vim.keymap.set("i", fecha, fechar(fecha), opts)
  end

  vim.keymap.set("i", "<BS>", backspace, opts)
  vim.keymap.set("i", "<CR>", enter, opts)
end

return M
