vim.opt.clipboard = "unnamedplus"
vim.keymap.set('t', '<esc>', [[<C-\><C-n>]])
vim.g.mapleader = ","
vim.opt.number = true

require("autopairs").setup()
